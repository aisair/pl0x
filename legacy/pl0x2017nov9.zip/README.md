November 9th 2017

pl0x is a 4k/5k skin with an arrow design.

There are standard assets, though it is mainly just filler of my personal skin so that you
	dont have to deal with the default skin.

All these assets can be used in your own skins,
	just credit me <3.
	
If you want source files pm me, I don't have every asset. They're all Adobe Illustrator files.

If you find problems let me know.

Known problems: White line in 5k mode, pm me if you have a fix.

