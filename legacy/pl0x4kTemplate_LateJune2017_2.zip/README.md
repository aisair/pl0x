------------- INFO -------------
This is a 4k Mania template to put over an existing skin.

------------- INSTRUCTIONS -------------
Begin by making a backup of the skin you would like to override, not mandatory.

Open the "@MANDATORY" folder and drag all of those files onto the skin of choice.
After, amend the data from the skin.ini file from this template into the 
	existing one in your skin folder.
(Please read the info inside the .ini)

-------------  SOUND  -------------
To add sounds, simply drag and drop the files in the "@RECOMMENDED - SOUNDS"
	folder into the main skin folder.
	
-------------  COMBO  -------------
To add combo, drag and drop the files in the "@RECOMMENDED - COMBO" folder
	into the skin folder and amend the data from 
	the combo.ini into the existing skin.ini file.
(Please read the info inside the .ini)

------------- CURSOR-------------
To add the cursor, drag and drop the files from the "EXTRA CURSOR" folder 
	into the skin folder and amend the data from the cursor.ini into the 
	existing skin.ini file.
Only add if you find the design neat, works well on standard.