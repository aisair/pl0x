December 17th 2017

forum post: https://osu.ppy.sh/forum/t/619322 (Don't forget to vote in the poll so I have a better understanding).
If you were reccomended this skin by a friend, or found this with a search engine, it'd be appreciated if you filled out this survey https://goo.gl/forms/svUvRFEd1J8IyTdx1

pl0x is a 4k/5k skin with an arrow design.

All these assets can be used in your own PERSONAL skins,
	just credit me or something <3.
	
If you want source files pm me, I don't have every asset. They're all Adobe Illustrator files.

If you find problems let me know.

Known problems: White line in 5k mode, pm me if you have a fix.



