This is a 4k Mania template to put over an existing skin.

Begin by making a backup of the skin you would like to override, not mandatory.

Open the "@MANDATORY" folder and drag all of those files onto the skin of choice.
After, amend the data from the skin.ini file from this template into the existing one in yor skin folder.
(Read the info inside)

To add sounds, simply drag and drop into the skin folder

To add combo, drag and drop into the skin folder and amend the data from the combo.ini into the existing skin.ini file.
(Read the info inside)

To add the cursor, drag and drop into the skin folder and amend the data from the cursor.ini into the existing skin.ini file.
Only add if you find the design neat, works well on standard.