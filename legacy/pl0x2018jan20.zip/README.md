January 20th 2018

forum post: https://osu.ppy.sh/forum/t/619322
(Don't forget to vote in the poll so I have a better understanding).

pl0x is a 4k/5k skin with an arrow design.
	It also includes standard assets and a sharp arrow modification.
	
PM ME if: you find problems, want the source Adobe Illustrator files.

You can use these assets in your own personal skin, just credit me somewhere <3

Known problems: White line in 5k mode, pm me if you have a fix.

##############################################
HOW TO INSTALL SHARP ARROWS:
	Load skin into game and find the folder it installed in
	Navigate to the "mania" folder
	In this zip file there is a folder named "sharp--mod"
	Drag the "arrows" folder in "sharp--mod" into the installed skin directory and overwrite everything
	Note: this will delete the rounded design, and you may have to reinstall the osk file