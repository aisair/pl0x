September 28th 2018

forum post: https://osu.ppy.sh/community/forums/topics/619322
(Don't forget to vote in the poll!).

pl0x is a 4k/5k skin with an arrow design.
	It also includes standard assets and plenty of custom "arrow" modifications.

##############################################
HOW TO INSTALL MODDED ARROWS:
	Navigate to the "mania/arrows" folder in the skin's installed directory
	In this zip file there is a folder named "ARROW MODS"
	Find the mod you want in this folder, for example: "arrow_sharp" and drag its contents into mania/arrows/ of the installed skin folder.
	Note: To get default arrows use "arrow_round"